import type { Command } from '../../shared/model/commands';
export function rpcCommand(cmd: Command) {
    if(['startResearch','pauseResearch','debugResearch'].includes(cmd.type))return {fn:'peris_empire_command',args:{p_command:cmd}};
    if(cmd.type==='raidCity')return {fn:'peris_empire_command',args:{p_command:cmd}};
    if (cmd.type === 'readAllReports') return { fn: 'peris_read_all_reports', args: {} };
    if (cmd.type === 'readReports') return { fn: 'peris_read_reports', args: { p_report_ids: cmd.reportIds } };
    if (cmd.type === 'researchUnit') return { fn: 'peris_research_unit', args: { p_city: cmd.settlementId, p_unit: cmd.item } };
    if (cmd.type === 'collectGarrison') return { fn: 'peris_collect_garrison', args: { p_army: cmd.armyId, p_troops: cmd.troops ?? null } };
    if (['saveCampaignFarmList', 'saveCampaignFarm', 'deleteCampaignFarm', 'deleteCampaignFarmList', 'startCampaignFarmList', 'manageCampaignFarmTargets', 'setCampaignFarmListEnabled', 'applyCampaignFarmListTroops'].includes(cmd.type))
        return { fn: 'peris_campaign_farm_command', args: { p_command: cmd } };
    if (cmd.type === 'cancelMarch' || (cmd.type === 'raid' || cmd.type === 'move') && cmd.troops !== undefined)
        return { fn: 'peris_empire_command', args: { p_command: cmd } };
    const scoped=['trainSettlers','foundCity','recruitHero','heroSkill','equipArtifact','transferTroops','rebaseArmy','upgrade','buildSlot','upgradeSlot','recruit','move','raid','claimField','buildField','researchSpell','rename','claim','setFaction','debugCity','challenge','respond'];
    if(scoped.includes(cmd.type)&&(cmd.settlementId!==undefined||cmd.armyId!==undefined||['trainSettlers','foundCity','recruitHero','heroSkill','equipArtifact','transferTroops','rebaseArmy'].includes(cmd.type)))return {fn:'peris_empire_command',args:{p_command:cmd}};
    let fn = '', args: Record<string, unknown> = {};
    if (cmd.type === 'claimField') { fn = 'peris_claim_field'; args = { p_col: cmd.col, p_row: cmd.row }; }
    if (cmd.type === 'buildField') { fn = 'peris_queue_field'; args = { p_col: cmd.col, p_row: cmd.row, p_type: cmd.item }; }
    if(cmd.type==='setFaction'){fn='peris_set_faction';args={p_faction:cmd.faction};}
    if(cmd.type==='debugCity'){fn='peris_debug_city';args={p_action:cmd.action,p_target:cmd.target??null,p_value:cmd.value??null};}
    if(cmd.type==='researchSpell'){fn='peris_research_spell';args={p_spell:cmd.spell};}
    if(cmd.type==='castSpell'){fn='peris_cast_spell';args={p_battle_id:cmd.battleId,p_spell:cmd.spell,p_target:cmd.target??null};}
    if (cmd.type==='buildSlot' || cmd.type==='upgradeSlot') {
        fn='peris_queue_slot';args={p_slot:cmd.slot,p_type:cmd.type==='buildSlot'?cmd.item:null};
    }
    if (cmd.type === 'upgrade') {
        fn = 'peris_queue_upgrade';
        args = { p_type: cmd.item };
    }
    if (cmd.type === 'recruit') {
        fn = 'peris_queue_recruit';
        args = { p_type: cmd.item, p_quantity: cmd.quantity };
    }
    if (cmd.type === 'move') {
        fn = cmd.route ? 'peris_march' : 'move_army';
        args = { p_target_x: Math.round(cmd.x), p_target_y: Math.round(cmd.y) };
        if (cmd.route) args.p_path = cmd.route;
    }
    if (cmd.type === 'raid') {
        fn = 'peris_raid';
        args = { p_camp_id: cmd.campId };
    }
    if (cmd.type === 'ready') {
        fn = 'peris_ready';
        args = { p_battle_id: cmd.battleId };
    }
    if (cmd.type === 'order') {
        fn = 'peris_order';
        args = { p_battle_id: cmd.battleId, p_order: cmd.order };
    }
    if (cmd.type === 'rally') {
        fn = 'peris_rally';
        args = { p_battle_id: cmd.battleId };
    }
    if (cmd.type === 'retreat') {
        fn = 'retreat_from_battle';
        args = { p_battle_id: cmd.battleId };
    }
    if (cmd.type === 'claim') {
        fn = 'peris_claim';
        args = { p_quest_id: cmd.questId };
    }
    if (cmd.type === 'rename') {
        fn = 'peris_rename';
        args = { p_name: cmd.name };
    }
    if (cmd.type === 'challenge') {
        fn = 'peris_challenge';
        args = { p_defender: cmd.ownerId };
    }
    if (cmd.type === 'respond') {
        fn = 'peris_respond';
        args = { p_id: cmd.id, p_accept: cmd.accept };
    }
    return { fn, args };
}



/// <reference types="vite/client" />
